#include "str_lib.h"

int diff(char *s1, char *s2) {
    int total = 0;
    
    int i;
    for (i = 0; *(s1+i) != '\0' && *(s2+i) != '\0'; i++) {
        if (tolower(*(s1+i)) == tolower(*(s2+i))) {
            total++;
        }
    }
    
    return total;
}
