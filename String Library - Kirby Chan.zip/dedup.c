#include "str_lib.h"

char *dedup(char *s) {
    char *t=s;
    while (*t!='\0') {
        t++;
    }
    
    static char nodup[50];
    int k = 0;
    for (int i = 0; i < t-s; i++) {
        int j;
        for (j = 0; j < i; j++) {
            if (tolower(*(s+j)) == tolower(*(s+i))) {
                break;
            }
        }
        if (j == i) {
            nodup[k++] = *(s+i);
        }
    }
    nodup[k] = '\0';
    return nodup;
}
