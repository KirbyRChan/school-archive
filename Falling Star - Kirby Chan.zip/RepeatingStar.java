
public class RepeatingStar extends FallingStar {
	
	public RepeatingStar(int updateInterval, int windowLength) {
		super(updateInterval, windowLength);
	}

	@Override
	public void move() {
		if(position < windowLength - 1) {
			position++;
		}
		else if(position == windowLength - 1) {
			position = 0;
		}
	}

}