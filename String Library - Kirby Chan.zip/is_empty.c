#include "str_lib.h"

int is_empty(char *s) {
    if (s == NULL) {
        return 1;
    }
    
    for (int i = 0; *(s+i) != '\0'; i++) {
        if (!isspace(*(s+i))) {
            return -1;
        }
    }
    
    return 1;
}