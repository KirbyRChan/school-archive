#include "str_lib.h"
#include <math.h>

char *pad(char *s, int d) {
    if (s == NULL) {
        return NULL;
    }
    
    char *t=s;
    while (*t!='\0') {
        t++;
    }
    int len = d * floor((double)(t-s)/d) + d;
    static char padded[50];
    
    int i;
    for (i = 0; i < t-s; i++) {
        padded[i] = *(s+i);
    }
    for (; i < len; i++) {
        padded[i] = ' ';
    }
    padded[i] = '\0';
    
    return padded;
}
