public class ResizableStar extends FallingStar {

	private boolean isMovingRight;
	
	public ResizableStar(int updateInterval, int windowLength) {
		super(updateInterval, windowLength);
	}

	@Override
	public void move() {
		if(isMovingRight && position < windowLength - 2) {
			position++;
		}
		else if(!isMovingRight && 0 < position) {
			position--;
		}
		else if(windowLength != 1) {
			isMovingRight = !isMovingRight;
			this.move();
		}
	}
	public void draw() {
		String window = "";
		for(int i = 0; i < windowLength; i++) {
			if(i == position || i == position+1) {
				window += "0";
			}
			else {
				window += "-";

			}
		}
		System.out.println(window);
	}

}