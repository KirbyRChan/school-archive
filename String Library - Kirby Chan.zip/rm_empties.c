#include "str_lib.h"

void rm_empties(char **words) {
    for (int i = 0; words[i] != NULL; i++) {
        char *word = words[i];
        char *worda = word;
        while (*worda != '\0') {
            worda++;
        }
        if (worda-word == 0) {
            words[i] = NULL;
        }
    }
}