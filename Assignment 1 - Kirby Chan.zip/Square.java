
public class Square extends Rectangle {
	
	public Square (double length) {
		super(length, length);
	}
}
