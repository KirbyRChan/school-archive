public class Visualizer {
	
	private FallingStar star;
	
	public Visualizer(FallingStar star) {
		this.star = star;
	}
	
	public void start() {
		while(true) {
			try {
				Thread.sleep(star.getUpdateInterval());
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			star.draw();
			star.move();
		}
	}
	
}