
public class Rectangle extends Shape2D {
	
	private double width, height;
	
	public Rectangle (double width, double height) {
		this.width = width;
		this.height = height;
	}
	public Boolean equals (Rectangle otherRect) {
		if (width == otherRect.width && height == otherRect.height) {
			return true;
		}
		else {
			return false;
		}
	}
	
	@Override
	public double computeArea() {
		return width*height;
	}
	
	@Override
	public String toString() {
		return "(" + width + ", " + height + ")";	
	}
}
