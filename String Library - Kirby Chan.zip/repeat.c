#include "str_lib.h"

char *repeat(char *s, int x, char sep) {
    char*t = s;
    while (*t != '\0') {
        t++;
    }
    
    static char rep[50];
    int index = 0;
    for (int i = 0; i < x; i++) {
        t = s;
        while(*t != '\0') {
            rep[index++] = *t;
            t++;
        }
        rep[index++] = sep;
    }
    rep[index-1] = '\0';
    
    return rep;
}
