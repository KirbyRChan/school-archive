#include "str_lib.h"

int len_diff(char *s1, char *s2) {
    int s1_len = 0;
    int s2_len = 0;
    
    while (*s1 != '\0') {
        s1_len++;
        s1++;
    }
    while (*s2 != '\0') {
        s2_len++;
        s2++;
    }
    
    return s1_len - s2_len;
}