#include "str_lib.h"

void rm_left_space(char *s) {
    int spaceNum = 0;
    
    while(isspace(*s)) {
        spaceNum++;
        s++;
    }
    while(*s != '\0') {
        *(s-spaceNum) = *s;
        *s = '\0';
        s++;
    }
}