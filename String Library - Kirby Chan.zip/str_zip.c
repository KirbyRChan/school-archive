#include "str_lib.h"

char *str_zip(char *s1, char *s2) {
    char *s1a = s1;
    char *s2a = s2;
    int len = 0;
    
    while (*s1a != '\0') {
        len++;
        s1a++;
    }
    while (*s2a != '\0') {
        len++;
        s2a++;
    }
    
    static char zip[50];
    
    int i = 0;
    while(*s1 != '\0' || *s2 != '\0') {
        if (*s1 != '\0') {
            zip[i] = *s1;
            s1++;
            i++;
        }
        if (*s2 != '\0') {
            zip[i] = *s2;
            s2++;
            i++;
        }
    }
    zip[len] = '\0';
    
    return zip;
}
