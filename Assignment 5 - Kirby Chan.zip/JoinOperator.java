import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JoinOperator {

    // Assignment 5:
    //
    // Consider tables A and B that share a single column whose name
    // is stored in the variable uniqueKey.
    // Every cell in this column has a unique value.
    //
    // GOAL:
    //
    // It is your job to build a new table that joins the data from
    // A and B based on the column uniqueKey.
    //
    // SUBPROBLEMS:
    //
    // (a) The new table must have a map consisting of the column names
    // from A and B (10 pts)
    //
    // (b) In order to match rows from A and B that agree on column uniqueKey,
    // you must use a HashMap (15 pts)
    //
    // (c) After matching rows, you must build new rows that join together
    // the data from A and B (10 pts)
    //
    // (d) Complete the join method and pass the sanity check (10 pts)
    //
    public static Table join(Table A, Table B, String uniqueKey) {
    	Map<String, Integer> hashMapA = createHashMap(A, uniqueKey);
    	Map<String, Integer> hashMapB = createHashMap(B, uniqueKey);   	
    	
    	Map<String, Integer> columnNames = joinColumnNames( A.columnNamesMap(), B.columnNamesMap() );
       	List<Row> rows = new ArrayList<Row>();
    	
       	for (int i = 0; i < B.size() ; i++) {
        	int rowIndexFromA = hashMapA.get( B.getCell(i, uniqueKey) );
        	int rowIndexFromB = hashMapB.get( B.getCell(i, uniqueKey) );
        	
        	rows.add( joinSingleRow( columnNames, A, B, rowIndexFromA, rowIndexFromB ) );
        }
    	
       	return new Table(columnNames, rows);
    }

    // (Optional) You may use the following as a helper method for part (a)
    // Build and return a new map such that the new map contains all of the
    // keys from columnNamesFromA and all of the keys from columnNamesFromB.
    // The new map sends each key to an integer index. If there are n keys,
    // then each integer index from 0 to n - 1 is used once.
    private static Map<String, Integer> joinColumnNames(Map<String, Integer> columnNamesFromA,
        Map<String, Integer> columnNamesFromB) {
        Map<String, Integer> columnNamesForNewTable = new HashMap<String,Integer>();
        
        int i = 0;
        for (String key : columnNamesFromA.keySet()) {
        	columnNamesForNewTable.put(key, i);
            i++;
        }
        for (String key : columnNamesFromB.keySet()) {
        	if (!columnNamesForNewTable.containsKey(key)) {
        		columnNamesForNewTable.put(key, i);
        		i++;
        	}
        }
        
        return columnNamesForNewTable;
    }

    // (Optional) You may use the following as a helper method for part (b)
    // Build and return a HashMap that sends strings to row indexes such
    // that the HashMap allows you to lookup the index of a row that
    // contains a specified string value in column uniqueKey.
    private static Map<String, Integer> createHashMap(Table A, String uniqueKey) {
        Map<String, Integer> hashMap = new HashMap<String, Integer>();
        
        for (int i = 0; i < A.size(); i++) {
        	hashMap.put(A.getCell(i, uniqueKey), i);
        }
        
        return hashMap;
    }

    // (Optional) You may use the following as a helper method for part (c)
    // Build and return a row that joins together data from the specified
    // row from A and the specified row from B.
    private static Row joinSingleRow(Map<String, Integer> columnNamesForNewTable, Table A, Table B, int rowIndexFromA,
            int rowIndexFromB) {
        String[] data = new String[ columnNamesForNewTable.size() ];

        for (String key : columnNamesForNewTable.keySet()) {
        	if ( A.columnNamesMap().containsKey(key) ) {
            	data[ columnNamesForNewTable.get(key) ] = A.getCell(rowIndexFromA, key);
        	}
            else if ( B.columnNamesMap().containsKey(key) ) {
            	data[ columnNamesForNewTable.get(key) ] = B.getCell(rowIndexFromB, key);
            }
        }

    	return new Row(data);
    }

}
