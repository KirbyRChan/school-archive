#include "str_lib.h"

void shorten(char *s, int new_len) {
    char *t=s;
    while (*t!='\0') {
        t++;
    }
    if ((t-s) > new_len) {
        *(s + new_len) = '\0';
    }
}