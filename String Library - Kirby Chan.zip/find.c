#include "str_lib.h"

int find(char *h, char *n) {
    char *ha = h;
    char *na = n;
    
    while (*ha != '\0') {
        ha++;
    }
    while (*na != '\0') {
        na++;
    }
    
    if ( (na-n) > (ha-h) ) {
        return -1;
    }
    
    for(int i = 0; *(h+i) != '\0'; i++) {
        if(*(h+i) == *n) {
            for(int j = 0; *(n+j) != '\0'; j++) {
                if(*(h+i+j) != *(n+j)) {
                    break;
                }
                else if(j == na-n-1) {
                    return i;
                }
            }
        }
    }
    return -1;
}