#include "str_lib.h"
#include <stdio.h>
#include <ctype.h>
#include <math.h>


int main() {
    
    char str1[] = "spongebob1";
    char str2[] = "PATRICK";
    
    printf("all_letters Test: %s -> %d\n", str1, all_letters(str1));
    printf("all_letters Test: %s -> %d\n", str2, all_letters(str2));
    
    printf("\nnum_in_range Test: %s, b, g -> %d\n", str1, num_in_range(str1,'b','g'));
    
    printf("\nshorten Test: %s, 9 -> ", str1);
    shorten(str1, 9);
    printf("%s\n", str1);
    
    printf("\nlen_diff Test: %s %s -> %d\n", str1, str2, len_diff(str1,str2));
    
    char str3[] = "   Hello   ";
    char str4[] = "   World   ";
    
    printf("\nrm_left_space Test: \"%s\" -> ", str3);
    rm_left_space(str3);
    printf("\"%s\"\n", str3);
    
    printf("\nrm_right_space Test: \"%s\" -> ", str3);
    rm_right_space(str3);
    printf("\"%s\"\n", str3);
    
    printf("\nrm_space Test: \"%s\" -> ", str4);
    rm_space(str4);
    printf("\"%s\"\n", str4);
    
    char str5[] = "potato";
    char str6[] = "tato";
    
    printf("\nfind Test: %s %s -> %d\n", str5, str6, find(str5, str6));
    
    printf("\nptr_to Test: %s %s -> %s\n", str5, str6, ptr_to(str5, str6));
    
    printf("\nis_empty Test: %s -> %d\n", str1, is_empty(str1));
    
    printf("\nstr_zip Test: %s %s -> %s\n", str1, str2, str_zip(str1, str2));
    
    char str7[] = "there's alWays mOney in the bAnana staNd.";
    
    printf("\ncapitalize Test: %s -> ", str7);
    capitalize(str7);
    printf("%s\n", str7);
    
    printf("\nstrcmp_ign_case Test: %s %s -> %d\n", str5, str6, strcmp_ign_case(str5,str6));
    
    printf("\ntake_last Test: %s 4 -> ", str5);
    take_last(str5, 4);
    printf("%s\n", str5);
    
    printf("\ndedup Test: %s -> %s\n", str7, dedup(str7));
    
    printf("\npad Test: \"%s\" 5 -> \"%s\"\n", str5, pad(str5, 5));
    
    char str8[] = "heroic";
    char str9[] = "oic";
    
    printf("\nends_with_ignore_case Test: %s %s -> %d\n", str8, str9, ends_with_ignore_case(str8,str9));
    
    printf("\nrepeat Test: %s 3 ',' -> %s\n", str2, repeat(str2, 3, ','));
    
    char str10[] = "hello xx xx";
    printf("\nreplace Test: %s 'xx' 'world' -> %s\n", str10, replace(str10, "xx", "world"));
    
    char *a[4];
    a[0] = "blah";
    a[1] = "hmm";
    a[2] = "duh";
    a[3] = "";
    printf("\nstr_connect Test: %s %s %s + -> %s\n", "blah", "hmm", "duh", str_connect(a, 3, '+'));
    
}
