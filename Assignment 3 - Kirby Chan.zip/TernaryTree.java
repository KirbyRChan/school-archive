import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TernaryTree<E> {

	public Vertex<E> root;
	
	public TernaryTree(Vertex<E> root) {
		this.root = root;
	}
	
    // Problem 1: Fill in the methods preorder and postorder below.
	// These methods should traverse the TernaryTree adding vertices
	// to a list in the specified order.  Then, the list of vertices
	// should be returned.
	public List<Vertex<E>> preorder() {
		List<Vertex<E>> vertices = new ArrayList<Vertex<E>>();
		recursivePreorder(root, vertices);
		
		return vertices;
	}
	
	public void recursivePreorder(Vertex<E> current, List<Vertex<E>> vertices) {
		if(current != null) {
			vertices.add(current);
			recursivePreorder(current.leftChild, vertices);
			recursivePreorder(current.middleChild, vertices);
			recursivePreorder(current.rightChild, vertices);
		}
	}

	public List<Vertex<E>> postorder() {
		List<Vertex<E>> vertices = new ArrayList<Vertex<E>>();
		recursivePostorder(root, vertices);
			
		return vertices;
	}
		
	public void recursivePostorder(Vertex<E> current, List<Vertex<E>> vertices) {
		if(current != null) {
			recursivePostorder(current.leftChild, vertices);
			recursivePostorder(current.middleChild, vertices);
			recursivePostorder(current.rightChild, vertices);
			vertices.add(current);
		}
	}

    // Problem 2: Fill in the method getSize below.
	// This method should use recursion to compute the total number
	// of vertices in the TernaryTree.
    public int getSize() {
        return recursiveGetSize(root);
    }
    
    public int recursiveGetSize(Vertex<E> current) {
    	if(current == null) {
    		return 0;
    	}
    	return 1 + recursiveGetSize(current.leftChild) + recursiveGetSize(current.middleChild) + recursiveGetSize(current.rightChild);
    }

    // Problem 3: Fill in the method getLeafVertices below.
    // This method should return a list of all vertices that are
    // leafs in the TernaryTree.
    public List<Vertex<E>> getLeafVertices() {
    	List<Vertex<E>> leaves = new ArrayList<Vertex<E>>();
    	recursivegetLeafVertices(root, leaves);

    	return leaves;
    }
    
    public void recursivegetLeafVertices(Vertex<E> current, List<Vertex<E>> leaves) {
		if (current != null) {
			if(current.leftChild == null && current.middleChild == null && current.rightChild == null) {
				leaves.add(current);
			}
			else {
			recursivegetLeafVertices(current.leftChild, leaves);
			recursivegetLeafVertices(current.middleChild, leaves);
			recursivegetLeafVertices(current.rightChild, leaves);
			}
		}
	}
	
    // Problem 4: Fill in the method remove below.
    // This method should remove all vertices (and their subtrees)
    // that contain the given label.  This method should call
    // the equals method to make comparisons.
    public void remove(E label) {
    	recursiveRemove(root, label);
    	
    }
    
    public void recursiveRemove(Vertex<E> current, E label) {
    	if (current != null) {
    		if (current.parent == null && current.label.equals(label)) {
    			current = null; 			
    		}
    		if (current.leftChild != null && current.leftChild.label.equals(label)) {
    			current.leftChild.parent = null;
    			current.leftChild = null;
    		}
    		if (current.middleChild != null && current.middleChild.label.equals(label)) {
    			current.middleChild.parent = null;
    			current.middleChild = null;
    		}
    		if (current.rightChild != null && current.rightChild.label.equals(label)) {
    			current.rightChild.parent = null;
    			current.rightChild = null;
    		}
    		
    		recursiveRemove(current.leftChild, label);
    		recursiveRemove(current.middleChild, label);
    		recursiveRemove(current.rightChild, label);
    	}
    }
}
