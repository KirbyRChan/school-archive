public class ZigZagStar extends FallingStar {

	private boolean isMovingRight;
	
	public ZigZagStar(int updateInterval, int windowLength) {
		super(updateInterval, windowLength);
	}

	@Override
	public void move() {
		if(isMovingRight && position < windowLength - 1) {
			position++;
		}
		else if(!isMovingRight && 0 < position) {
			position--;
		}
		else if(windowLength != 1) {
			isMovingRight = !isMovingRight;
			this.move();
		}
	}

}