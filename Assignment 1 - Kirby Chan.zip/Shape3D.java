
public abstract class Shape3D {
	public abstract double computeSurfaceArea();
}
