#include "str_lib.h"

void take_last(char *s, int n) {
    char *t = s;
    while (*t != '\0') {
        t++;
    }
    
    if (t-s <= n) {
        return;
    }
    
    int i;
    for (i = 0; i < n; i++) {
        *(s+i) = *(t+i-n);
    }
    *(s+i) = '\0';
}
