import java.util.*;

public class RandomizedStar extends FallingStar {

	Random rn = new Random();

	public RandomizedStar(int updateInterval, int windowLength) {
		super(updateInterval, windowLength);
	}

	@Override
	public void move() {
		if (position == 0)
			position++;
		else if (position == windowLength - 2)
			position--;
		else {
			int i = rn.nextInt(2);
			if (i == 0)
				position--;
			else if (i == 1)
				position++;
		}

	public void draw() {
		String window = "";
		for(int i = 0; i < windowLength; i++) {
			if(i == position || i == position+1) {
				window += "0";
			}
			else {
				window += "-";
			}
		}
		System.out.println(window);
	}
}