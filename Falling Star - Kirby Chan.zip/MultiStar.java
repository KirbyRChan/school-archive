public class MultiStar extends FallingStar {

	private boolean isMovingRight;
	
	public MultiStar(int updateInterval, int windowLength) {
		super(updateInterval, windowLength);
	}

	@Override
	public void move() {
		if(isMovingRight && position < windowLength - 1) {
			position++;
		}
		else if(!isMovingRight && 0 < position) {
			position--;
		}
		else if(windowLength != 1) {
			isMovingRight = !isMovingRight;
			this.move();
		}
	}
	public void draw() {
		String window = "";
		for(int i = 0; i < windowLength; i++) {
			if(i == position || i == (windowLength-1) -position) {
				window += "0";
			}
			else {
				window += "-";
			}
		}
		System.out.println(window);
	}
}