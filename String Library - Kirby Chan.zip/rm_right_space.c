#include "str_lib.h"

void rm_right_space(char *s) {
    while (*s != '\0') {
        s++;
    }
    s--;
   
    while(isspace(*s)) {
        *s = '\0';
        s--;
    }
}