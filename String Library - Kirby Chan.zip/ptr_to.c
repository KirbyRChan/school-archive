#include "str_lib.h"

char *ptr_to(char *h, char *n) {
    char *ha = h;
    char *na = n;
    
    while (*ha != '\0') {
        ha++;
    }
    while (*na != '\0') {
        na++;
    }
    
    if ( (na-n) > (ha-h) ) {
        return NULL;
    }
    
    int i,j;
    for(i = 0; *(h+i) != '\0'; i++) {
        if(*(h+i) == *n) {
            for(j = 0; *(n+j) != '\0'; j++) {
                if(*(h+i+j) != *(n+j)) {
                    break;
                }
                else if(j == na-n-1) {
                    return h+i;
                }
            }
        }
    }
    return NULL;
}