import java.util.*;

public class Main {

	public static void main(String[] args) {
		List<Shape2D> shapes = new ArrayList<Shape2D>();
		
		shapes.add( new Rectangle(3.0, 8.0) );
		shapes.add( new Rectangle(4.0, 6.0) );
		shapes.add( new Rectangle(2.0, 12.0) );
		shapes.add( new Rectangle(4.0, 1.0) );
		shapes.add( new Rectangle(2.0, 4.0) );
		shapes.add( new Rectangle(4.0, 3.0) );
		shapes.add( new Rectangle(6.0, 2.0) );
		shapes.add( new Rectangle(11.0, 1.0) );
		
		List<Shape2D> largestShapes = Shape2D.getLargestShapes(shapes);
		
		System.out.println("The largest shapes are: \n");
		for (int i = 0; i < largestShapes.size(); i++) {
			System.out.println(largestShapes.get(i).toString());
		}
		System.out.println("\nwith the area of: " + largestShapes.get(0).computeArea());
	}		
}
