#include "str_lib.h"

void capitalize(char *s) {
    for (int i = 0; *(s+i) != '\0'; i++) {
        if (i == 0) {
            *(s+i) = toupper(*(s+i));
        }
        else if (isspace(*(s+i))) {
            i++;
            *(s+i) = toupper(*(s+i));
        }
        else {
            *(s+i) = tolower(*(s+i));
        }
    }
}