public class Main {

	public static void main(String[] args) {
		FallingStar myStar = new ResizableStar(140, 20);
		Visualizer visualizer = new Visualizer(myStar);
		visualizer.start();
	}
	
}