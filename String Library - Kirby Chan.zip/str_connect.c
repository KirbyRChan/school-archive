#include "str_lib.h"

char *str_connect(char **strs, int n, char c) {
    static char connect[100];
    
    int index = 0;
    for (int i = 0; i < n; i++) {
        char *a = strs[i];
        while (*a != '\0') {
            connect[index++] = *a;
            a++;
        }
        connect[index++] = c;
    }
    connect[--index] = '\0';
    
    return connect;
}
