#include "str_lib.h"

char *replace(char *s, char *pat, char *rep) {
    char *pata = pat;
    char *repa = rep;

    while (*pata != '\0') {
        pata++;
    }
    while (*repa != '\0') {
        repa++;
    }
    
    static char replaced[100];

    int index = 0;
    for(int i = 0; *(s+i) != '\0'; i++) {
        int valid = 0;
        if(*(s+i) == *pat) {
            for(int j = 0; *(pat+j) != '\0'; j++) {
                if(*(s+i+j) != *(pat+j)) {
                    break;
                }
                else if(j == pata-pat-1) {
                    valid = 1;
                    i += (pata-pat-1);
                    repa = rep;
                    while (*repa != '\0') {
                        replaced[index++] = *repa;
                        repa++;
                    }
                }
            }
        }
        if (valid == 0) {
            replaced[index++] = *(s+i);
        }
    }
    replaced[index] = '\0';

    return replaced;
}
