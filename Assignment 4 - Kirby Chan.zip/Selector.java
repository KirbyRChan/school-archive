
public class Selector {

    // This is a helper method
    public static void swap(Word[] array, int i, int j) {
        Word temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    // Problem #1 (5 pts)
    // Fill in the following method with an O(n*k) time algorithm
    // that returns the k largest elements of array in order from
    // largest to smallest.
    // Note: This should return an array with k elements.
    // Hint: Your approach should be similar to selection sort.
    public static Word[] simpleSelect(Word[] array, int k) {
    	Word[] wordArray = array.clone();
    	Word[] largestWords = new Word[k];
    	
        for (int i = 0; i < k; i++) {
        	Word max = wordArray[i];
        	for (int j = i+1; j < wordArray.length; j++) {
        		if (wordArray[j].compareTo(max) > 0) {
        			max = wordArray[j];
        			swap(wordArray, i, j);
        		}
        	}
           	largestWords[i] = max;
        }
    	return largestWords;
    }

    // Problem #4 (5 pts)
    // Fill in the following method with an O(n + klog(n)) time algorithm
    // that returns the k largest elements of array in order from
    // largest to smallest.
    // Note: This should return an array with k elements.
    // Hint: Your approach should use a BinaryHeap.
    public static Word[] heapSelect(Word[] array, int k) {
        BinaryHeap bin = new BinaryHeap(array);
        Word[] largestWords = new Word[k];
        
        for (int i = 0; i < k; i++) {
        	largestWords[i] = bin.removeMax();
        }
        
    	return largestWords;
    }

}
