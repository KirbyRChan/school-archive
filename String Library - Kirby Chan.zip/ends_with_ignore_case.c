#include "str_lib.h"

int ends_with_ignore_case(char *s, char *suff) {
    char *sa = s;
    char *suffa = suff;
    
    while (*sa != '\0') {
        sa++;
    }
    while (*suffa != '\0') {
        suffa++;
    }

    if ( suffa-suff > sa-s) {
        return 0;
    }
    
    for (int i = 0; i < suffa-suff; i++) {
        if (tolower(*(suff+i)) != tolower(*(sa-(suffa-suff)+i))) {
            return 0;
        }
    }
    return 1;
}