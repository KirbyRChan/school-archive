#include "str_lib.h"

int all_letters(char *s) {
    while (*s != '\0') {
        if (!isalpha(*s)) {
            return 0;
        }
        s++;
    }
    return 1;
}