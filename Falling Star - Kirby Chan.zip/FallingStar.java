public abstract class FallingStar {
	
	protected int position;
	protected int updateInterval;
	protected int windowLength;
	
	public FallingStar(int updateInterval, int windowLength) {
		this.position = 0;
		this.updateInterval = updateInterval;
		this.windowLength = windowLength;
	}
	
	public void draw() {
		String window = "";
		for(int i = 0; i < windowLength; i++) {
			if(i == position) {
				window += "0";
			}
			else {
				window += "-";
			}
		}
		System.out.println(window);
	}

	public int getUpdateInterval() {
		return updateInterval;
	}
	
	public abstract void move();
	
}