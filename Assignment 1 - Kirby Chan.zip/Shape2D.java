import java.util.*;

public abstract class Shape2D implements Comparable<Shape2D> {

	public int compareTo(Shape2D otherShape) {
		if (this.computeArea() > otherShape.computeArea())
			return 1;
		else if (this.computeArea() == otherShape.computeArea())
			return 0;
		else
			return -1;
	}
	public abstract double computeArea();
	
	public abstract String toString();
	
	public static List<Shape2D> getLargestShapes(List<Shape2D> shapes) {
		double largestArea = 0.0;
		
		List<Shape2D> largestShapes = new ArrayList<Shape2D>();
		
		for (int i = 0; i < shapes.size(); i++) {
			if (shapes.get(i).computeArea() > largestArea)
				largestArea = shapes.get(i).computeArea();
		}	
		for (int i = 0; i < shapes.size(); i++) {
			if (shapes.get(i).computeArea() == largestArea)
				largestShapes.add(shapes.get(i));
		}
		
		return largestShapes;
	}
}

