
public class BinaryHeap {

    private Word[] wordArray;
    private int size;

    public BinaryHeap(Word[] array) {
        size = array.length;
        buildHeap(array);
    }

    // Problem #2 (20 pts)
    // Fill in the following method with an O(n) time algorithm
    // that builds an n element complete binary heap.
    // Note: You are allowed to add helper methods.
    public void buildHeap(Word[] array) {
    	wordArray = array.clone();
    	for (int i = size-1; i >= 0; i--) {
    		sink(i);
    	}
    }
    
    // Problem #3 (15 pts)
    // Fill in the following method with an O(log(n)) time algorithm
    // that removes the root element, restores the heap structure,
    // and finally returns the removed root element.
    // Note: You are allowed to add helper methods.
    public Word removeMax() {
    	Word removedWord = wordArray[0];
    	swap(0, size-1);
    	size--;
    	sink(0);
    	
    	return removedWord;
    		
    }
    
    private void sink(int i) {
    	while ( 2*i+1 < size ) {
			if ( 2*i+2 < size ) {
	    		int compare = wordArray[2*i+1].compareTo( wordArray[2*i+2] );
	    		
	    		if ( compare >= 0 && wordArray[2*i+1].compareTo( wordArray[i] ) > 0 ) {
	    			swap(i, 2*i+1);
	    			i = 2*i+1;
	    		}
	    		else if ( compare < 0 && wordArray[2*i+2].compareTo( wordArray[i] ) > 0 ) {
	    			swap(i, 2*i+2);
	    			i = 2*i+2;
	    		}
	    		else {
	    			break;
	    		}
	    	}
	    	else {
	    		if ( wordArray[2*i+1].compareTo( wordArray[i] ) > 0 ) {
	    			swap(i, 2*i+1);	
	    			i = 2*i+1;
	    		}
	    		else {
	    			break;
	    		}
	    	}
		}
    }

	private void swap(int i, int j) {
		Word temp = wordArray[i];
		wordArray[i] = wordArray[j];
		wordArray[j] = temp;
	}	
}