
public abstract class PlatonicSolid extends Shape3D{
	double edgeLength;
	int numOfFaces;
	
	public abstract double computeAreaOfOneFace();
		
	public double computeSurfaceArea() {
		return numOfFaces*this.computeAreaOfOneFace();
	}

}
