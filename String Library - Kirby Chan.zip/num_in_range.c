#include "str_lib.h"

int num_in_range(char *s1, char b, char t) {
    int total = 0;
    
    while (*s1 != '\0') {
        if (*s1 >= b && *s1 <= t) {
            total++;
        }
        s1++;
    }
    return total;
}